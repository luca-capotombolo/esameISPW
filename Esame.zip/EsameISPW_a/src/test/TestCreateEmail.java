package test;


import logic.Client;
import logic.CreateEmail;
import logic.Email;

import static org.junit.Assert.*;

import org.junit.Test;



public class TestCreateEmail {

	@Test
	public void testNotifyClient()
	{
		Client winner = new Client("liuk", "liuk99", 100.0, "pippoPluto@gmail.com");
		CreateEmail createEmail = new CreateEmail();
		Email esitoWinner;
		Email esitoLoser;
		
		int count = 0;
		esitoLoser = createEmail.notifyClient(new Client("elvira", 100.0,"Elvira@tiscali.it"),winner);
		esitoWinner = createEmail.notifyClient(new Client("liuk", "liuk99", 100.0, "pippoPluto@gmail.com"), winner);
		
		if(esitoLoser.getMessage().equals("Sorry, you are not the winner of the auction.")) {
			count++;
		}
		
		if(esitoWinner.getMessage().equals("Hi "+winner.getNickname()+"\n"+"Congratulations, you have won the auction!")) {
			count++;
		}
		
		assertEquals(2,count);
	}
}
