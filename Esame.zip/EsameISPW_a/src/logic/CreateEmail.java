package logic;



public class CreateEmail {
	
	private String messageClientWinner = "Congratulations, you have won the auction!";
	private String messageClientLoser = "Sorry, you are not the winner of the auction.";
	
	public Email notifyClient(Client client, Client winner)
	{
		
		Email email = null;
		
		
		if(client.getUsername().equals(winner.getUsername()) && client.getNickname().equals(winner.getNickname())) {
			email = new Email(client.getUsername(),client.getEmail() , "Hi "+client.getNickname()+"\n"+messageClientWinner);
		}
		else
		{
			email = new Email(client.getUsername(),client.getEmail(), messageClientLoser);
		}
		
		return email;
	}
}
