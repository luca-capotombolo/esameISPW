package logic;

public class Client {
	
	private String username;
	private String nickname;
	private double maximumAmount;
	private String email;
	
	public Client(String username, String nickname, double maximumAmount,String email) {
		this.username = username;
		this.nickname = nickname;
		this.maximumAmount = maximumAmount;
		this.email = email;
	}
	

	public Client(String username, double maximumAmount,String email) {
		this.username = username;
		this.maximumAmount = maximumAmount;
		this.email = email;
	}


	
	public String getNickname() {
		return nickname;
	}


	public String getEmail() {
		return email;
	}


	public String getUsername() {
		return username;
	}


	

	

	
	
	
}
