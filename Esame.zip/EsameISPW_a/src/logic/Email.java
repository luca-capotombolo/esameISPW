package logic;

public class Email {
	private String username;
	private String emailClient;
	private String message;
	
	public Email(String username, String email, String message) {
		this.username = username;
		this.emailClient = email;
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	

	
	
	
}
